/***************************************
 * @author:Alex Wang
 * @Date:2017/10/6
 * @QQ: 532500648
 *
 * The utilities of Joiner will be demo by test case {@link JoinerTest}
 * The utilities of Splitter will be demo by test case {@link SplitterTest}
 * The utilities of PreConditions will be demo by test case {@link PreConditionsTest}
 ***************************************/
package com.wangwenjun.guava.utilities;