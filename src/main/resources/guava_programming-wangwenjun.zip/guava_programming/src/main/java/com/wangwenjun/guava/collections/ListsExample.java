package com.wangwenjun.guava.collections;

/***************************************
 * @author:Alex Wang
 * @Date:2018/1/13
 * QQ: 532500648
 * QQ群:463962286
 ***************************************/
public class ListsExample
{
}
