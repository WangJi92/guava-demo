package com.wangwenjun.guava.eventbus.events;

/***************************************
 * @author:Alex Wang
 * @Date:2017/10/19
 * 532500648
 ***************************************/
public class Response
{
}
