package com.wangwenjun.guava.eventbus.events;

/***************************************
 * @author:Alex Wang
 * @Date:2017/10/18
 * 532500648
 ***************************************/
public class Apple extends Fruit
{
    public Apple(String name)
    {
        super(name);
    }
}
