package com.wangwenjun.guava.io;

import org.junit.Test;

/***************************************
 * @author:Alex Wang
 * @Date:2017/10/14
 * @QQ: 532500648
 ***************************************/
public class CharSinkTest {

    /**
     * CharSource---->Reader
     * <p>
     * CharSink------>Writer
     */
    @Test
    public void testCharSink() {

    }

}