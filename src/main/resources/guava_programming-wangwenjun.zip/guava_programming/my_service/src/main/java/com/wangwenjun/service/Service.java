package com.wangwenjun.service;

/***************************************
 * @author:Alex Wang
 * @Date:2017/10/11
 * @QQ: 532500648
 ***************************************/
public interface Service {

    void show();
}
